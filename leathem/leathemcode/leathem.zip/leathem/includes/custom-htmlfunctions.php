<?php
	function displayHead() {
?>
		<meta charset="UTF-8">
		<title>Fix Fee Divorce - Leathems</title>
		<link href='http://fonts.googleapis.com/css?family=Lato:400,700' rel='stylesheet' type='text/css'>
		<link href='http://fonts.googleapis.com/css?family=Julius+Sans+One' rel='stylesheet' type='text/css'>
		<link href="/css/style.css" rel="stylesheet" type="text/css">
<?php
	}
	
	function displayHeader() {
	?>
		<header>
			<a href="/" class="logo">
				<img src="images/logo.jpg" alt="Leathems Solicitors">
			</a>
			<nav>
				<ul>
					<li><a href="#">Property</a></li>
					<li><a href="#">Wills</a></li>
					<li><a href="#">Family</a></li>
					<li><a href="#">LPA</a></li>
					<li><a href="#">Commercial</a></li>
					<li><a href="#">FAQ</a></li>
					<li><a href="#">Contact</a></li>
					<li><a href="tel:+441663733431">+44 (0) 1663 733 431</a></li>
				</ul>
			</nav>
		</header>
	<?php
	}
	
	function displayFooter() {
	?>
		<footer>
			<div class="accredition">
				<img src="images/accredited-img1.jpg" alt="The Law Society - Conveyancing Quality"><img src="images/accredited-img2.jpg" alt="The Law Society - Family Quality">
			</div>
			<address>
				Leathem Solicitors,<br>
				12 Market Street, Whaley Bridge, High Peak, Derbyshire, SK23 7LP.<br>
				Office: +44 (0)1663 733 431 | Fax: +44 (0)1663 735 488.<br>
				General enquiries: enquire@leathems.com | DX:28468 Whaley Bridge.
			</address>
			<p>&copy; Copyright 2015 - Leathems Solicitors. Authorised & Regulated by the Solicitors Regulation Authority (SRA number 305971).</p>
		</footer>
	<?php
	}
?>