<?php
	include_once("includes/custom-dbfunctions.php");
	include_once("includes/custom-htmlfunctions.php");
	include_once("includes/custom-phpfunctions.php");

	extract($_GET);

	if(!isset($url)) {
		$url = 'index';
	}

	if($url == 'index') {
		include_once('home.php');
	}
?>