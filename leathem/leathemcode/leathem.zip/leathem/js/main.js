$(document).ready(function(){
	$(".step1").on("click",function(){
	  if($(".step1:checked").length > 0) {
		if($("#artstep2").hasClass("disable")) {
		  $("#artstep2").removeClass("disable");
		}
	  } else {
		if(!$("#artstep2").hasClass("disable")) {
		  $("#artstep2").addClass("disable");
		} 
	  }
	});
});