<!doctype html>
<html lang="en">
 <head>
<?php
	displayHead();
?>
 </head>
 <body>
  <div class="wrapper">
 <?php
	displayHeader();
 ?>
 <main>
			<div class="heading">
				<h1>Fix - Fee Divorce</h1>
				<em>Making the law simpler for you.</em>
			</div>
			<p class="descriptive-para">
				<strong>How it works</strong>
				To help you with your divorce and to budget effectively we have developed a fixed fee scheme. This will ensure you know exactly what you are paying for and what it will cost. Where appropriate we can conduct your case under one or a series of fixed prices. You can choose what aspects you want us to deal with. Fixed fees are not appropriate for every client and you may prefer our hourly rate package. Below is our fixed fee menu.
				<span>All prices include VAT but there may be additional court fees.</span>
			</p>
			<hr>
			<article>
				<h2>1. Choose how we meet</h2>
				<div class="boxed-cont act">
					<div class="text-cont">
						<strong>Initial meeting</strong>
						<p>This is a meeting of up to 20 minutes either in person or over the phone with a qualified solicitor. This allows us to assess how we might be able to help you.</p>
					</div>
					<div class="price-cont">
						<span>
							Free
							<input type="checkbox" name="step-1" class="step1"  value="0">
						</span>
					</div>
				</div>
				<div class="boxed-cont">
					<div class="text-cont">
						<strong>Initial meeting Plus</strong>
						<p>2. Initial meeting plus - This is a meeting of  up to 1 hour either in person or over the phone for a fixed fee of &pound;120. This is ideal for those people just wanting some initial advice on their options. It then enables you to decide what further advice or help you may need.</p>	
					</div>
					<div class="price-cont">
						<span>
							&pound;120
							<input type="checkbox"  name="step-1" class="step1" value="120">
						</span>
					</div>
				</div>
			</article>
			<article class="disable" id="artstep2">
				<h2>2. Choose a divorce package</h2>
				<div class="boxed-cont">
					<div class="text-cont">
						<strong>Assisted DIY divorce package - petitioner</strong>
						<p>This includes a one-hour meeting with a qualified solicitor who will be happy to provide you with guidance and answer your questions about the divorce process.<br><br>We will provide you with a divorce Pack containing;-<br>all forms you are likely to need to conduct straightforward divorce yourself. Notes written by a qualified solicitor guiding you through the divorce process. A further half hour of legal advice by phone or in person and we will check the documents prior to them being filed with the court</p>
					</div>
					<div class="price-cont">
						<span>
							&pound;360
							<input type="checkbox"  value="360">
						</span>
					</div>
				</div>
				<div class="boxed-cont">
					<div class="text-cont">
						<strong>Managed undefended - petitioner</strong>
						<em>&pound;540 costs plus &pound;410 court fee</em>
						<p>This includes an initial meeting with a qualified divorce solicitor.<br>We will complete all the paperwork for you and correspond with the court and your partner at all stages. There are no issues and the divorce is undefended.</p>
					</div>
					<div class="price-cont">
						<span>
							&pound;950
							<input type="checkbox"  value="950">
						</span>
					</div>
				</div>
				<div class="boxed-cont act">
					<div class="text-cont">
						<strong>Managed divorce plus - petitioner</strong>
						<em>&pound;900 costs plus &pound;410 court fee</em>
						<p>If your divorce  does not include complicated issues ,such as a disagreement with about what the basis of the divorce should be on , then this is this level for you if you feel that you may need a high level of contact or support from your solicitor as  your divorce progresses or if you need assistance which is not covered by our managed unde fended divorce service, but which are not serious enough to need extensive negotiations. You can always start on the managed undefended divorce package and upgrade to the managed divorce package by just paying the difference in price.<br><br>For this you will get up to 2 hours contact with your solicitor in addition to the managed undefended divorce package.</p>
					</div>
					<div class="price-cont">
						<span>
							&pound;1310
							<input type="checkbox"  value="1310">
						</span>
					</div>
				</div>
				<div class="boxed-cont">
					<div class="text-cont">
						<strong>Assisted DIY divorce - respondent</strong>
						<p>This includes a half-hour meeting with a qualified divorce solicitor. We will explain the divorce process to you and complete the forms on your behalf and return them to the court.</p>
					</div>
					<div class="price-cont">
						<span>
							&pound;270
							<input type="checkbox"  value="270">
						</span>
					</div>
				</div>
				<div class="boxed-cont">
					<div class="text-cont">
						<strong>Managed undefended divorce - respondent</strong>
						<p>This includes a one-hour meeting with a qualified divorce solicitor who will be happy to provide you with guidance and answer your questions about the divorce process. We will go through all the divorce papers with you and correspond with the court and your partner at all stages.</p>
					</div>
					<div class="price-cont">
						<span>
							&pound;480
							<input type="checkbox"  value="480">
						</span>
					</div>
				</div>
			</article>
			<section class="summary-cont">
				<h2>What you've choosen</h2>
				<dl>
					<dt>Initial Meeting</dt>
					<dd>Free</dd>
					<dt>Managed divorce plus - petitioner</dt>
					<dd class="totalval">&pound;1310</dd>
					<dt class="total">Total to pay</dt>
					<dd class="totalval">&pound;1310</dd>
				</dl>
			</section>
			<hr>
			<div class="paypal-cont">
				<h2>Pay now</h2>
				<p>Click to pay now with PayPal<br><b>and earn 5% discount</b></p>
				<a href="#"><img src="images/paypal-btn.jpg" alt="Checkout with PayPal"></a>
				<img class="card-icons" src="images/card-icons.jpg" alt="PayPal | Master Card | Maestro | Visa">
			</div>
			<form class="contact-form" id="contact-form" name="contact-form" method="post" >
				<fieldset>
					<legend>Need to discuss further?</legend>
					<p>Fill out the form to request a call back.</p>
					<input type="text" placeholder="First Name" required name="firstname" id="firstname">
					<input type="text" placeholder="Last Name" name="lastname" id="lastname">
					<input type="email" placeholder="Email Address" required name="emailaddress" id="emailaddress">
					<input type="tel" placeholder="Contact Number" required name="phone" id="phone">
					<button type="submit">Call Me</button>
				</fieldset>
			</form>
			<hr>
			<article>
				<h3>What is not included</h3>
				<p>These fixed  costs do not cover negotiations relating to finances or children and if these issues arise then we will discuss further costs with you as a fixed fee is not likely to be appropriate at that stage.<br><br>You can always opt for our full package which is on an hourly rate if there are complex issues arising or if you have chosen a fixed package at the outset then you can change package at any time. Simple ask a member of the team.</p>
			</article>
		</main>
<?php
	displayFooter();
?>
	</div>
	<script  src="http://code.jquery.com/jquery-1.11.1.min.js"></script>
	<script src="/js/main.js">
	</script>
 </body>
</html>
